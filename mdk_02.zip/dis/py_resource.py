# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.0
# WARNING! All changes made in this file will be lost!

from PyQt6 import QtCore

qt_resource_data = b"\
\x00\x00\x01+\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0z\x22 fil\
l=\x22none\x22/><path \
d=\x22M17 3H5c-1.11\
 0-2 .9-2 2v14c0\
 1.1.89 2 2 2h14\
c1.1 0 2-.9 2-2V\
7l-4-4zm-5 16c-1\
.66 0-3-1.34-3-3\
s1.34-3 3-3 3 1.\
34 3 3-1.34 3-3 \
3zm3-10H5V5h10v4\
z\x22/></svg>\
\x00\x00\x00\xfc\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0V0z\x22 f\
ill=\x22none\x22/><pat\
h d=\x22M16 9v10H8V\
9h8m-1.5-6h-5l-1\
 1H5v2h14V4h-3.5\
l-1-1zM18 7H6v12\
c0 1.1.9 2 2 2h8\
c1.1 0 2-.9 2-2V\
7z\x22/></svg>\
\x00\x00\x01\x1f\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0z\x22 fil\
l=\x22none\x22/><path \
d=\x22M19 19H5V5h7V\
3H5c-1.11 0-2 .9\
-2 2v14c0 1.1.89\
 2 2 2h14c1.1 0 \
2-.9 2-2v-7h-2v7\
zM14 3v2h3.59l-9\
.83 9.83 1.41 1.\
41L19 6.41V10h2V\
3h-7z\x22/></svg>\
\x00\x00\x01\x87\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0z\x22 fil\
l=\x22none\x22/><path \
d=\x22M15.5 14h-.79\
l-.28-.27C15.41 \
12.59 16 11.11 1\
6 9.5 16 5.91 13\
.09 3 9.5 3S3 5.\
91 3 9.5 5.91 16\
 9.5 16c1.61 0 3\
.09-.59 4.23-1.5\
7l.27.28v.79l5 4\
.99L20.49 19l-4.\
99-5zm-6 0C7.01 \
14 5 11.99 5 9.5\
S7.01 5 9.5 5 14\
 7.01 14 9.5 11.\
99 14 9.5 14z\x22/>\
</svg>\
\x00\x00\x02\x03\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 enable-ba\
ckground=\x22new 0 \
0 24 24\x22 height=\
\x2224px\x22 viewBox=\x22\
0 0 24 24\x22 width\
=\x2224px\x22 fill=\x22#F\
FFFFF\x22><g><rect \
fill=\x22none\x22 heig\
ht=\x2224\x22 width=\x222\
4\x22/></g><g><g/><\
g><path d=\x22M17,1\
9.22H5V7h7V5H5C3\
.9,5,3,5.9,3,7v1\
2c0,1.1,0.9,2,2,\
2h12c1.1,0,2-0.9\
,2-2v-7h-2V19.22\
z\x22/><path d=\x22M19\
,2h-2v3h-3c0.01,\
0.01,0,2,0,2h3v2\
.99c0.01,0.01,2,\
0,2,0V7h3V5h-3V2\
z\x22/><rect height\
=\x222\x22 width=\x228\x22 x\
=\x227\x22 y=\x229\x22/><pol\
ygon points=\x227,1\
2 7,14 15,14 15,\
12 12,12\x22/><rect\
 height=\x222\x22 widt\
h=\x228\x22 x=\x227\x22 y=\x221\
5\x22/></g></g></sv\
g>\
\x00\x00\x01;\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0z\x22 fil\
l=\x22none\x22/><path \
d=\x22M13 7h-2v4H7v\
2h4v4h2v-4h4v-2h\
-4V7zm-1-5C6.48 \
2 2 6.48 2 12s4.\
48 10 10 10 10-4\
.48 10-10S17.52 \
2 12 2zm0 18c-4.\
41 0-8-3.59-8-8s\
3.59-8 8-8 8 3.5\
9 8 8-3.59 8-8 8\
z\x22/></svg>\
\x00\x00\x01A\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0V0z\x22 f\
ill=\x22none\x22/><pat\
h d=\x22M16 5l-1.42\
 1.42-1.59-1.59V\
16h-1.98V4.83L9.\
42 6.42 8 5l4-4 \
4 4zm4 5v11c0 1.\
1-.9 2-2 2H6c-1.\
11 0-2-.9-2-2V10\
c0-1.11.89-2 2-2\
h3v2H6v11h12V10h\
-3V8h3c1.1 0 2 .\
89 2 2z\x22/></svg>\
\
\x00\x00\x01L\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0z\x22 fil\
l=\x22none\x22/><path \
d=\x22M12 2C6.47 2 \
2 6.47 2 12s4.47\
 10 10 10 10-4.4\
7 10-10S17.53 2 \
12 2zm5 13.59L15\
.59 17 12 13.41 \
8.41 17 7 15.59 \
10.59 12 7 8.41 \
8.41 7 12 10.59 \
15.59 7 17 8.41 \
13.41 12 17 15.5\
9z\x22/></svg>\
\x00\x00\x01o\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0V0z\x22 f\
ill=\x22none\x22/><pat\
h d=\x22M14.06 9.02\
l.92.92L5.92 19H\
5v-.92l9.06-9.06\
M17.66 3c-.25 0-\
.51.1-.7.29l-1.8\
3 1.83 3.75 3.75\
 1.83-1.83c.39-.\
39.39-1.02 0-1.4\
1l-2.34-2.34c-.2\
-.2-.45-.29-.71-\
.29zm-3.6 3.19L3\
 17.25V21h3.75L1\
7.81 9.94l-3.75-\
3.75z\x22/></svg>\
\x00\x00\x00\xce\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x222\
4px\x22 viewBox=\x220 \
0 24 24\x22 width=\x22\
24px\x22 fill=\x22#FFF\
FFF\x22><path d=\x22M0\
 0h24v24H0z\x22 fil\
l=\x22none\x22/><path \
d=\x22M9 16.17L4.83\
 12l-1.42 1.41L9\
 19 21 7l-1.41-1\
.41z\x22/></svg>\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x13\
\x02\x94\xe6\xc7\
\x00s\
\x00a\x00v\x00e\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\x00.\x00s\
\x00v\x00g\
\x00\x15\
\x0f\x8f\xb3\x07\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\
\x00.\x00s\x00v\x00g\
\x00\x1a\
\x0b\xb7\xfdG\
\x00o\
\x00p\x00e\x00n\x00_\x00i\x00n\x00_\x00n\x00e\x00w\x00_\x00w\x00h\x00i\x00t\x00e\
\x00_\x002\x004\x00d\x00p\x00.\x00s\x00v\x00g\
\x00\x15\
\x06\x83h\xc7\
\x00s\
\x00e\x00a\x00r\x00c\x00h\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\
\x00.\x00s\x00v\x00g\
\x00\x17\
\x02\xf7\xf0'\
\x00p\
\x00o\x00s\x00t\x00_\x00a\x00d\x00d\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\
\x00d\x00p\x00.\x00s\x00v\x00g\
\x00!\
\x08\xab\xff\xe7\
\x00a\
\x00d\x00d\x00_\x00c\x00i\x00r\x00c\x00l\x00e\x00_\x00o\x00u\x00t\x00l\x00i\x00n\
\x00e\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\x00.\x00s\x00v\x00g\
\
\x00\x18\
\x06\xb0Q\x87\
\x00i\
\x00o\x00s\x00_\x00s\x00h\x00a\x00r\x00e\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\
\x004\x00d\x00p\x00.\x00s\x00v\x00g\
\x00\x15\
\x06\xd5\xe9'\
\x00c\
\x00a\x00n\x00c\x00e\x00l\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\
\x00.\x00s\x00v\x00g\
\x00\x13\
\x0ad\xa6G\
\x00e\
\x00d\x00i\x00t\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\x00.\x00s\
\x00v\x00g\
\x00\x14\
\x0eNQ\xe7\
\x00c\
\x00h\x00e\x00c\x00k\x00_\x00w\x00h\x00i\x00t\x00e\x00_\x002\x004\x00d\x00p\x00.\
\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x0a\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8c!\xd1\x84\xaa\
\x00\x00\x00\xd6\x00\x00\x00\x00\x00\x01\x00\x00\x04\xdd\
\x00\x00\x01\x8b\x8f6\x89\xb0\
\x00\x00\x00\xa6\x00\x00\x00\x00\x00\x01\x00\x00\x03R\
\x00\x00\x01\x8c!\xd1N\xe1\
\x00\x00\x01R\x00\x00\x00\x00\x00\x01\x00\x00\x08#\
\x00\x00\x01\x8c!\xd1\x9b\xa9\
\x00\x00\x01\x88\x00\x00\x00\x00\x00\x01\x00\x00\x09h\
\x00\x00\x01\x8c!\xd1\xad\xd3\
\x00\x00\x01\x0a\x00\x00\x00\x00\x00\x01\x00\x00\x06\xe4\
\x00\x00\x01\x8c!\xd1N\xe1\
\x00\x00\x01\xb8\x00\x00\x00\x00\x00\x01\x00\x00\x0a\xb8\
\x00\x00\x01\x8b\x8f5\xc6`\
\x00\x00\x00l\x00\x00\x00\x00\x00\x01\x00\x00\x02/\
\x00\x00\x01\x8c!\xd1x\x0c\
\x00\x00\x01\xe4\x00\x00\x00\x00\x00\x01\x00\x00\x0c+\
\x00\x00\x01\x8c!\xd1R\x14\
\x00\x00\x00<\x00\x00\x00\x00\x00\x01\x00\x00\x01/\
\x00\x00\x01\x8b\x8f5Q0\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
