from PyQt6.QtSql import QSqlDatabase
import sqlite3

class Database:
    def __init__(self):
        super(Database, self).__init__()
        self.create_connection()

    def create_connection(self):
        self.db = sqlite3.connect('server.db')
        self.cursor = self.db.cursor()

        db_view = QSqlDatabase.addDatabase('QSQLITE')
        db_view.setDatabaseName('server.db')
        db_view.open()
        if not db_view.isOpen():
            print('Не удалось открыть базу данных')


    def execute_query_with_params(self, sql_query, values_query=None):
        try:
            if values_query is not None:
                self.cursor.execute(sql_query, values_query)
            else:
                self.cursor.execute(sql_query)
            self.db.commit()
        except Exception as e:
            print(f"Ошибка при выполнении запроса: {e}")


    def update_product_quantit(self, order):
        for product_id, kol in order.items():
            self.execute_query_with_params('''UPDATE products SET Количество = Количество - ? 
            WHERE id = ?''', [kol, product_id])

    def update_product_quantit_for_suppliers(self, order):
        for product_id, kol in order.items():
            self.execute_query_with_params('''UPDATE products SET Количество = Количество + ? 
            WHERE id = ?''', [kol, product_id])

    def query_add_new_column(self, table_name, param):
        self.execute_query_with_params(f'INSERT INTO {table_name} VALUES{tuple(param)};')

    def query_povtor(self, product_id):
        self.execute_query_with_params('SELECT * FROM structure_orders WHERE id = ? ', [product_id])
        data = self.cursor.fetchall()
        if not data:
            return True
        else:
            return False
    def query_add_product_of_orders(self, product_id, kol):
        self.execute_query_with_params('SELECT Количество FROM products WHERE id = ? ', [product_id])
        product_kol = int(self.cursor.fetchone()[0])

        if product_kol >= int(kol):
            self.execute_query_with_params('INSERT INTO structure_orders SELECT id, Название, Категория, Бренд, Характеристики, Опиcание, ?, Цена FROM products WHERE id = ?;', (kol, product_id))
            return True
        else:
            return False

    def query_add_product_of_supplies(self, product_id, kol):
        self.execute_query_with_params(
            'INSERT INTO structure_supplies SELECT id, Название, Категория, Бренд, Характеристики, Опиcание, ?, Цена FROM products WHERE id = ?;',
            (kol, product_id))

    def query_add_product_of_orders_open(self, product_id, kol, table_name):
        self.execute_query_with_params(f'INSERT INTO {table_name} SELECT id, Название, Категория, Бренд, Характеристики, Опиcание, ?, Цена FROM products WHERE id = ?;', (kol, product_id))



    def query_delete_column(self, table_name, id):
        self.execute_query_with_params(f'DELETE FROM {table_name} WHERE ID=?', [id])

    def query_delete_data(self, table_name):
        self.execute_query_with_params(f'DELETE  FROM {table_name} ')

    def query_update_type(self, table_name, id):
        self.execute_query_with_params(f'UPDATE {table_name} SET Тип = "Удаленный" WHERE id = ?;', [id])

    def update_id(self, table_name, id):
        self.execute_query_with_params(f'UPDATE {table_name} SET id = id - 1 WHERE id > ?;', [id])

    def query_sum_orders(self):
        self.execute_query_with_params(f'SELECT SUM(Количество * Цена) FROM structure_orders')
        data = self.cursor.fetchone()[0]
        sum_order = 0 if data == None else data
        return sum_order

    def query_sum_supplies(self):
        self.execute_query_with_params(f'SELECT SUM(Количество * Цена) FROM structure_supplies')
        data = self.cursor.fetchone()[0]
        sum_order = 0 if data == None else data
        return sum_order

    def query_entry(self, login, password, position):
        self.execute_query_with_params(f'SELECT Логин, Пароль, Должность FROM workers where Логин = ? and Пароль = ? and Должность=?', [login, password, position])
        data = self.cursor.fetchall()
        return data
    def incr(self, table_name):
        self.execute_query_with_params(f'SELECT MAX(id) FROM {table_name}')
        data = self.cursor.fetchone()[0]
        incr_id = 1 if data == None else data + 1
        return incr_id
    def opr_structure(self, id, table_name):
        self.execute_query_with_params(f'SELECT Содержание FROM {table_name} WHERE ID = ?;', [id])
        data = self.cursor.fetchone()[0]
        return data




