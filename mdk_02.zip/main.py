from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QMessageBox, QDialog, QComboBox, QMenu
from PyQt6.QtSql import QSqlQueryModel
from PyQt6.QtGui import QAction
from PyQt6.QtCore import QDateTime, Qt
from dis_main import Ui_MainWindow
from database import Database
from dis_wid_add_workers import Ui_Dialog_workers
from dis_wid_add_products import Ui_Dialog_products
from dis_wid_add_order import Ui_Dialog
from dis_wid_kol_vo import Ui_Dialog_kol_vo
from dis_login import Ui_Form
import json
from docx import Document







class LoginForm(QWidget, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.datab = Database()
        self.but_login.clicked.connect(self.entry)

    def entry(self):
        data = self.datab.query_entry(self.r_le_login.text(), self.r_le_password.text(), self.r_comboBox_position.currentText())
        print(data, self.r_le_login.text(), self.r_le_password.text(), self.r_comboBox_position.currentText())
        if data == []:
            QMessageBox.critical(self, 'Ошибка', 'Неправильные данные!')
        else:
            self.openMainWindow(self.r_comboBox_position.currentText())

    def openMainWindow(self, position):
        self.mainWindow = MainWindow()
        self.mainWindow.show()
        if position == 'Сотрудник':
            self.mainWindow.action_workers.setVisible(False)
        self.close()

class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle("Главное окно")
        #self.showMaximized()
        self.tableView.resizeColumnsToContents()
        self.tableView.resizeRowsToContents()

        self.tableView.verticalHeader().setVisible(False)
        self.but_add.setVisible(False)
        self.but_redac.setVisible(False)

        self.datab = Database()
        self.widget_add_ord = widget_add_order()
        self.widget_kol = QDialog()
        self.widget_add = QDialog()
        self.table_name = 'orders'
        self.operation = None
        self.data_input = []
        self.param = []
        self.order = {}
        self.suppliers = {}
        self.sum = None
        self.id = None

        self.action_suppliers = QAction('Поставки', self)
        self.m_tables.addAction(self.action_suppliers)

        self.action_suppliers.triggered.connect(lambda checked, table_name='supplies': self.opr_table(table_name))
        self.action_products.triggered.connect(lambda checked, table_name='products': self.opr_table(table_name))
        self.action_workers.triggered.connect(lambda checked, table_name='workers': self.opr_table(table_name))
        self.action_orders.triggered.connect(lambda checked, table_name='orders': self.opr_table(table_name))
        self.action_about.triggered.connect(self.show_about_info)
        self.action_exit.triggered.connect(self.close_all_windows)

        self.but_add.clicked.connect(lambda: self.openWingetAdd(self.table_name))
        self.but_redac.clicked.connect(lambda: self.openWingetAdd(self.table_name))
        self.but_delete.clicked.connect(lambda: self.delete_column(self.table_name))
        self.but_order.clicked.connect(self.openWingetAddOrder)
        self.but_supliers.clicked.connect(self.openWingetAddSuppliers)
        self.but_search.clicked.connect(self.search_column)
        self.but_open.clicked.connect(self.open_order)
        self.tableView.clicked.connect(self.opr_products)

        self.widget_add_ord.but_save_order.clicked.connect(lambda: self.save_order(self.operation))
        self.widget_add_ord.but_delete_order.clicked.connect(lambda: self.delete_column_for_orders_suppliers(self.operation))
        self.widget_add_ord.but_cancel_order.clicked.connect(self.cancel_order)
        self.widget_add_ord.but_print_order.clicked.connect(self.print_structure_order_in_word)

        #sql_query_table = f'SELECT * FROM {self.table_name}' if self.table_name != 'orders' else f'SELECT id, Дата, Сумма FROM {self.table_name}'
        sql_query_table = f'SELECT id, Дата, Сумма FROM {self.table_name}' if self.table_name == 'orders' or self.table_name == 'supplies' else  f'SELECT * FROM {self.table_name}'

        self.view_data(self.tableView, sql_query_table)
        self.message_box = QMessageBox()



    def print_structure_order_in_word(self):
        try:
            if self.id != None:
                self.datab.execute_query_with_params(f'SELECT Дата FROM {self.table_name} WHERE ID = {self.id}')
                time = self.datab.cursor.fetchone()[0]
            else:
                time = QDateTime.currentDateTime().toString('dd.MM.yy hh:mm:ss')


            sql_query_table = 'SELECT * FROM structure_orders' if self.table_name == 'orders' else 'SELECT * FROM structure_supplies'
            type_document = 'Накладная' if self.table_name == 'orders' else 'Поставка'
            type_seller = 'Продавец' if self.table_name == 'orders' else 'Поставщик'

            self.datab.execute_query_with_params(sql_query_table)
            data = self.datab.cursor.fetchall()

            doc = Document()
            doc.add_heading(f'{type_document} {time}\n', level=1).paragraph_format.alignment = 1

            columns = [description[0] for description in self.datab.cursor.description]
            table = doc.add_table(rows=1, cols=len(columns))
            table.style = 'TableGrid'

            for col_num, column in enumerate(columns):
                table.cell(0, col_num).text = column

            for row in data:
                row_cells = table.add_row().cells
                for col_num, value in enumerate(row):
                    row_cells[col_num].text = str(value)

            total_amount_paragraph = doc.add_paragraph()
            total_amount_run = total_amount_paragraph.add_run(f'Общая сумма:')
            total_amount_paragraph.add_run(f' {self.sum}\n').bold = True
            total_amount_paragraph.alignment = 2

            buyer = doc.add_paragraph()
            buyer = buyer.add_run('Покупатель: __________________  ________')
            buyer.alignment = 0

            seller = doc.add_paragraph()
            seller = seller.add_run(f'{type_seller}: _____________________  ________')
            seller.alignment = 0

            doc.save('output.docx')
            self.widget_add_ord.message_word()

        except Exception as e:
            print(f"Ошибка при выполнении запроса: {e}")


    def view_data(self, tableview, sql_query):
        self.model1 = QSqlQueryModel()
        self.model1.setQuery(sql_query)
        tableview.setModel(self.model1)

    def opr_id_cursor(self, tableview):
        index = tableview.selectedIndexes()[0]
        id = str(tableview.model().data(index))
        return id

    def view_order(self):
        self.view_data(self.widget_add_ord.tableView_2, f'SELECT * FROM structure_orders')
        self.sum = f'{self.datab.query_sum_orders()} Р'
        self.widget_add_ord.lb_sum_order_pr.setText(self.sum)

    def view_supplies(self):
        self.view_data(self.widget_add_ord.tableView_2, f'SELECT * FROM structure_supplies')
        self.sum = f'{self.datab.query_sum_supplies()} Р'
        self.widget_add_ord.lb_sum_order_pr.setText(self.sum)

    def opr_table(self, table_name):
        self.table_name = table_name
        if self.table_name in ['orders','supplies']:
            self.but_open.setVisible(True)
            self.but_add.setVisible(False)
            self.but_redac.setVisible(False)
        else:
            self.but_open.setVisible(False)
            self.but_add.setVisible(True)
            self.but_redac.setVisible(True)
        #sql_query_table = f'SELECT * FROM {self.table_name}' if self.table_name != 'orders' else f'SELECT id, Дата, Сумма FROM {self.table_name}'
        sql_query_table = f'SELECT id, Дата, Сумма FROM {self.table_name}' if self.table_name == 'orders' or self.table_name == 'supplies' else  f'SELECT * FROM {self.table_name}'

        self.view_data(self.tableView, sql_query_table)

    def openWingetAdd(self, table_name):
        if table_name == 'workers':
            self.widget_add = widget_add_workers()
            self.data_input = [self.widget_add.le_name, self.widget_add.le_surname, self.widget_add.le_patronymic, self.widget_add.le_login, self.widget_add.le_password, self.widget_add.date_birh, self.widget_add.le_phone, self.widget_add.combox_position]

        elif table_name == 'products':
            self.widget_add = widget_add_products()
            self.data_input = [self.widget_add.le_name_products, self.widget_add.le_category_products, self.widget_add.le_brand_products, self.widget_add.le_chracteristic_products, self.widget_add.le_description_products, self.widget_add.le_quantity_products, self.widget_add.le_price_products, self.widget_add.lb_tip]

        self.widget_add.show()
        sender = self.sender()
        if sender.text() == 'Добавить':
            self.widget_add.but_save_add.clicked.connect(lambda: self.add_new_column(self.data_input))
        else:
            self.widget_add.but_save_add.clicked.connect(lambda: self.update_column(self.data_input))
            
    def add_new_column(self, list_in):
        id = self.datab.incr(self.table_name)
        self.opr_param(id, list_in)
        self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

    def update_column(self, list_in):
        try:
            id = self.opr_id_cursor(self.tableView)
            self.datab.query_delete_column(self.table_name, id)
            self.opr_param(id, list_in)
        except:
            self.message_box.information(self, 'Внимание', 'Выберите ID')

    def opr_param(self, id, data_input):
        if self.table_name == 'products' and (not self.data_input[5].text().isdigit() or not self.data_input[6].text().isdigit()):
            self.message_box.information(self, 'Внимание', 'Неправильные данные! \nПоля Количество и Цена должны содержать числа!')
        else:
            self.param.append(id)
            for data in data_input:
                value = data.text() if not isinstance(data, QComboBox) else data.currentText()
                self.param.append(value)

            self.datab.query_add_new_column(self.table_name, self.param)
            self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

            self.param.clear()
            self.widget_add.close()
    def openWingetAddOrder (self):
        self.widget_add_ord.but_save_order.setVisible(True)
        self.widget_add_ord.but_delete_order.setVisible(True)
        self.action_workers.setEnabled(False)
        self.action_products.setEnabled(False)
        self.action_orders.setEnabled(False)
        self.opr_table('products')
        self.view_data(self.tableView, f'SELECT * FROM products WHERE Тип = "Активный"')
        self.table_name = 'products'
        self.operation = 'orders'
        self.widget_add_ord.show()
        self.view_order()


    def openWingetAddSuppliers(self):
        self.openWingetAddOrder()
        self.operation = 'supplies'
        self.view_supplies()

    def open_order(self):
        try:
            id = self.opr_id_cursor(self.tableView)
            self.id = id
            print(self.table_name)
            if self.table_name == 'orders':
                self.order = self.datab.opr_structure(id, self.table_name)
                self.order = json.loads(self.order.replace("'", "\""))
                for product_id, kol in self.order.items():
                    self.datab.query_add_product_of_orders_open(product_id, kol, 'structure_orders')
                self.view_order()

            elif self.table_name == 'supplies':
                self.suppliers = self.datab.opr_structure(id, self.table_name)
                self.suppliers = json.loads(self.suppliers.replace("'", "\""))
                for product_id, kol in self.suppliers.items():
                    self.datab.query_add_product_of_orders_open(product_id, kol, 'structure_supplies')
                self.view_supplies()

            self.widget_add_ord.but_save_order.setVisible(False)
            self.widget_add_ord.but_delete_order.setVisible(False)
            self.widget_add_ord.show()

        except Exception as e:
            print(f"Ошибка при выполнении запроса: {e}")
            self.message_box.information(self, 'Внимание', 'Выберите ID')

    def opr_products(self, index):
        print(self.table_name == 'products' , self.widget_add_ord.isVisible() , index.column() == 0)
        if self.table_name == 'products' and self.widget_add_ord.isVisible() and index.column() == 0:
            id = self.opr_id_cursor(self.tableView)
            if self.datab.query_povtor(id):
                self.widget_kol = widget_add_kol_vo()
                self.widget_kol.show()
                if self.operation == 'orders':
                    self.widget_kol.but_confirm.clicked.connect(lambda: self.opr_kol_vo_for_order(id))
                else:
                    self.widget_kol.but_confirm.clicked.connect(lambda: self.opr_kol_vo_for_suppliers(id))

            else:
                self.message_box.information(self, 'Внимание', 'Этот товар уже выбран!')
    def opr_kol_vo_for_order(self, id):
        kol_vo = self.widget_kol.le_kol.text()
        if kol_vo.isdigit() and int(kol_vo) > 0:
            if self.datab.query_add_product_of_orders(id, kol_vo):
                self.order[id] = kol_vo
                self.widget_kol.close()
                self.view_order()
            else:
                self.message_box.information(self, 'Внимание', 'Запрашиваемое количество товара больше доступного на складе! ')
        else:
            self.widget_kol.le_kol.setText('')
            self.widget_kol.le_kol.setPlaceholderText('Неправильные данные!')

    def opr_kol_vo_for_suppliers(self, id):
        kol_vo = self.widget_kol.le_kol.text()
        if kol_vo.isdigit() and int(kol_vo) > 0:
            self.datab.query_add_product_of_supplies(id, kol_vo)
            self.suppliers[id] = kol_vo
            self.widget_kol.close()
            self.view_supplies()
        else:
            self.widget_kol.le_kol.setText('')
            self.widget_kol.le_kol.setPlaceholderText('Неправильные данные!')

    def cancel_order(self):
        self.widget_add_ord.close()
        self.action_workers.setEnabled(True)
        self.action_products.setEnabled(True)
        self.action_orders.setEnabled(True)
        self.order.clear()
        self.suppliers.clear()
        self.id = None
        self.datab.query_delete_data('structure_orders')
        self.datab.query_delete_data('structure_supplies')
        #sql_query_table = f'SELECT * FROM {self.table_name}' if self.table_name != 'orders' else f'SELECT id, Дата, Сумма FROM {self.table_name}'
        sql_query_table = f'SELECT id, Дата, Сумма FROM {self.table_name}' if self.table_name == 'orders' or self.table_name == 'supplies' else  f'SELECT * FROM {self.table_name}'

        self.view_data(self.tableView, sql_query_table)



    def save_order(self, operation):
        try:
            if operation == 'orders':
                id = self.datab.incr('orders')
                time = QDateTime.currentDateTime().toString('dd.MM.yy hh:mm:ss')
                self.datab.update_product_quantit(self.order)
                order = f'{self.order}'
                self.datab.query_add_new_column('orders', [id, time, self.sum, order])
                self.cancel_order()

            elif operation == 'supplies':
                id = self.datab.incr('supplies')
                time = QDateTime.currentDateTime().toString('dd.MM.yy hh:mm:ss')
                self.datab.update_product_quantit_for_suppliers(self.suppliers)
                suppliers = f'{self.suppliers}'
                self.datab.query_add_new_column('supplies', [id, time, self.sum, suppliers])
                self.cancel_order()
            else:
                print(operation)
        except Exception as e:
            print(f"Ошибка при выполнении запроса: {e}")




    def delete_column(self, table_name):
        try:
            id = self.opr_id_cursor(self.tableView)

            if table_name == 'products':
                self.datab.query_update_type(table_name, id)
                self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

            else:
                self.datab.query_delete_column(table_name, id)
                self.datab.update_id(table_name, id)
                self.view_data(self.tableView, f'SELECT * FROM {self.table_name}')

        except Exception as e:
            self.message_box.information(self, 'Внимание', 'Выберите ID')

    def delete_column_for_orders_suppliers(self, operation):
        try:
            id = self.opr_id_cursor(self.tableView)
            print(operation, id)
            if operation == 'orders':
                id = self.opr_id_cursor(self.widget_add_ord.tableView_2)
                self.datab.query_delete_column('structure_orders', id)
                del self.order[id]
                self.view_order()

            elif operation == 'supplies':
                id = self.opr_id_cursor(self.widget_add_ord.tableView_2)
                self.datab.query_delete_column('structure_supplies', id)
                del self.suppliers[id]
                self.view_supplies()
            else:
                print(operation)

        except Exception as e:
            self.message_box.information(self, 'Внимание', 'Выберите ID')
    def search_column(self):
        id = self.le_name.text()
        #sql_query = f'SELECT * FROM {self.table_name} WHERE ID={id}' if self.table_name != 'orders' else f'SELECT id, Дата, Сумма FROM {self.table_name} WHERE ID={id}'
        sql_query = f'SELECT id, Дата, Сумма FROM {self.table_name}' if self.table_name == 'orders' or self.table_name == 'supplies' else  f'SELECT * FROM {self.table_name}'

        self.model1.setQuery(sql_query)
        self.tableView.setModel(self.model1)
    
    def show_about_info(self):
        self.message_box.information(self, 'Информация о программе',
                                'Название: Программа для обработки заказов\n'
                                'Автор: Асроров М. Н.\n'
                                'Год создания: 2023')

    def closeEvent(self, event):
        reply = self.message_box.question(self, 'Подтверждение', 'Вы уверены, что хотите закрыть приложение?', self.message_box.StandardButton.Yes | self.message_box.StandardButton.No, self.message_box.StandardButton.No)
        if reply == self.message_box.StandardButton.Yes:
            event.accept()
            self.widget_kol.close()
            self.widget_add.close()
            self.cancel_order()
        else:
            event.ignore()
    def close_all_windows(self):
        QApplication.closeAllWindows()

class widget_add_workers(QDialog, Ui_Dialog_workers):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)

class widget_add_products(QDialog, Ui_Dialog_products):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)

class widget_add_order(QDialog, Ui_Dialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.tableView_2.verticalHeader().setVisible(False)
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    def message_word(self):
        QMessageBox.information(self, 'Внимание', 'Успешно! ')


class widget_add_kol_vo(QDialog, Ui_Dialog_kol_vo):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setModal(True)

def main():
    app = QApplication([])
    window = LoginForm()
    window.show()
    app.exec()

if __name__ == "__main__":
    main()
